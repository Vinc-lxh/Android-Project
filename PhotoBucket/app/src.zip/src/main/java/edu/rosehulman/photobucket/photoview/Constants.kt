package edu.rosehulman.photobucket.photoview

class Constants {
    companion object{
        val TAG: String = "errPhoto"
    }

}
