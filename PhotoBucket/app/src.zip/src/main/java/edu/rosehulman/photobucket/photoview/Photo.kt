package edu.rosehulman.photobucket.photoview

data class Photo(var caption: String = "", var URL: String = "", var isSelected: Boolean = false) {

}