import androidx.lifecycle.ViewModel
import edu.rosehulman.tictactoe.LinearLightOut

class LinearLightOutViewModel  : ViewModel() {
    var linearLightOut = LinearLightOut()

}