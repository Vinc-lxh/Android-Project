package edu.rosehulman.MovieQuote

object Constants {

    val TAG: String = "errMQ"
}
